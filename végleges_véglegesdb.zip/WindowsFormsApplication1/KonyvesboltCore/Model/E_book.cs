﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.Model
{
    public class E_book : Termek
    {
        public E_book(Termek termek)
        {
            ID = termek.ID;
            Cim = termek.Cim;
            Kiadas_eve = termek.Kiadas_eve;
            Ar = termek.Ar;
        }
        public string Szerzo { get; set; }
    }
}
