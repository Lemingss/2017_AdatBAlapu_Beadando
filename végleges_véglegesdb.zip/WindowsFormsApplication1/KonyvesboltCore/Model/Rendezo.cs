﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.Model
{
    public class Rendezo
    {
        public int ID { get; set; }
        public string RendezoNeve { get; set; }
    }
}
