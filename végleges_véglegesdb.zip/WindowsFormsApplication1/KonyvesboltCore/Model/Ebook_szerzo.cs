﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.Model
{
    public class Ebook_szerzo
    {
        public int ID { get; set; }
        public string Szerzo { get; set; }
    }
}
