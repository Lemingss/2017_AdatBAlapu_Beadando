﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.Model
{
    public class Termek
    {
        public int ID { get; set; }
        public string Cim { get; set; }
        public int Kiadas_eve { get; set; }
        public int Ar { get; set; }
    }
}
