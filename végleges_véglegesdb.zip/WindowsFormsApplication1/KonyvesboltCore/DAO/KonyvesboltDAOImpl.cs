﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KonyvesboltGUI.Model;
using Oracle.ManagedDataAccess.Client;

namespace KonyvesboltGUI.DAO
{
    public class KonyvesboltDAOImpl : KonyvesboltDAO
    {
        private const string DATABASE_CONNECTION_STRING_FORMAT_STRING = "Data Source={0}";

        private readonly string s_connectionString;

        public KonyvesboltDAOImpl(string databasePath)
        {
            s_connectionString = string.Format(DATABASE_CONNECTION_STRING_FORMAT_STRING, databasePath);
        }

        #region termék felvitele az adatbázisba
        public bool ujTermek(Konyv konyv)
        {
            bool rvSucc = false;
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                {   
                    //A konyv termékkel kapcsolatos részeit beletesszük a Termek táblába
                    command.CommandText = "INSERT INTO TERMEK (CIM, KIADAS_EVE, AR) VALUES (@cim, @kiadas_eve, @ar)";
                    command.Parameters.Add("cim", OracleDbType.Varchar2).Value = konyv.Cim;
                    command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = konyv.Kiadas_eve;
                    command.Parameters.Add("ar", OracleDbType.Int32).Value = konyv.Ar;
                    if (command.ExecuteNonQuery() == 1)
                    {
                        //Kikeressük az auto incrementelt ID-t amit kaptunk az előző INSERT után
                        command.CommandText = "SELECT ID FROM TERMEK WHERE CIM = @cim AND KIADAS_EVE = @kiadas_eve";
                        command.Parameters.Add("cim", OracleDbType.Varchar2).Value = konyv.Cim;
                        command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = konyv.Kiadas_eve;
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //Kikeressük a terméket ami az ID-hez tartozik (tudom előbb tettük be, de lol)
                            termekek = ReadTermekFromReader(reader);
                            if (termekek.Count == 1)
                            {
                                //Ha megvan beállítjuk a külső kulcsát a könyv táblában
                                command.CommandText = "INSERT INTO KONYV (TERMEK_ID) VALUES (@id)";
                                command.Parameters.Add("id", OracleDbType.Int32).Value = termekek[0].ID;
                                if (command.ExecuteNonQuery() == 1)
                                {
                                    //Ha ez is meg van, beállítjuk a szerző táblát is
                                    command.CommandText = "INSERT INTO KONYV_SZERZO (KONYV_TERMEK_ID, SZERZO) Values (@id, @szerzo)";
                                    command.Parameters.Add("id", OracleDbType.Int32).Value = termekek[0].ID;
                                    command.Parameters.Add("szerzo", OracleDbType.Varchar2).Value = konyv.Szerzo;
                                    rvSucc = command.ExecuteNonQuery() == 1;
                                }
                            }
                        }
                    }
                }
            }
            return rvSucc;
        }

        public bool ujTermek(E_book ebook)
        {
            bool rvSucc = false;
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                {
                    //Az ebook termékkel kapcsolatos részeit beletesszük a Termek táblába
                    command.CommandText = "INSERT INTO TERMEK (CIM, KIADAS_EVE, AR) VALUES (@cim, @kiadas_eve, @ar)";
                    command.Parameters.Add("cim", OracleDbType.Varchar2).Value = ebook.Cim;
                    command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = ebook.Kiadas_eve;
                    command.Parameters.Add("ar", OracleDbType.Int32).Value = ebook.Ar;
                    if (command.ExecuteNonQuery() == 1)
                    {
                        //Kikeressük az auto incrementelt ID-t amit kaptunk az előző INSERT után
                        command.CommandText = "SELECT ID FROM TERMEK WHERE CIM = @cim AND KIADAS_EVE = @kiadas_eve";
                        command.Parameters.Add("cim", OracleDbType.Varchar2).Value = ebook.Cim;
                        command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = ebook.Kiadas_eve;
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //Kikeressük a terméket ami az ID-hez tartozik (tudom előbb tettük be, de lol)
                            termekek = ReadTermekFromReader(reader);
                            if (termekek.Count == 1)
                            {
                                //Ha megvan beállítjuk a külső kulcsát az e_book táblában
                                command.CommandText = "INSERT INTO E_BOOK (TERMEK_ID) VALUES (@id)";
                                command.Parameters.Add("id", OracleDbType.Int32).Value = termekek[0].ID;
                                if (command.ExecuteNonQuery() == 1)
                                {
                                    //Ha ez is meg van, beállítjuk a szerző táblát is
                                    command.CommandText = "INSERT INTO KONYV_SZERZO (KONYV_TERMEK_ID, SZERZO) Values (@id, @szerzo)";
                                    command.Parameters.Add("id", OracleDbType.Int32).Value = termekek[0].ID;
                                    command.Parameters.Add("szerzo", OracleDbType.Varchar2).Value = ebook.Szerzo;
                                    rvSucc = command.ExecuteNonQuery() == 1;
                                }
                            }
                        }
                    }
                }
            }
            return rvSucc;
        }
        //Utóbbi kettőnél is ugyanaz, mint előző, csak itt nincs szerző tábla, egy plusz Rendező, ill. Együttes_neve paraméter van az ID-k mellett a végén
        public bool ujTermek(Film film)
        {
            bool rvSucc = false;
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                {
                    command.CommandText = "INSERT INTO TERMEK (CIM, KIADAS_EVE, AR) VALUES (@cim, @kiadas_eve, @ar)";
                    command.Parameters.Add("cim", OracleDbType.Varchar2).Value = film.Cim;
                    command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = film.Kiadas_eve;
                    command.Parameters.Add("ar", OracleDbType.Int32).Value = film.Ar;
                    if (command.ExecuteNonQuery() == 1)
                    {
                        command.CommandText = "SELECT ID FROM TERMEK WHERE CIM = @cim AND KIADAS_EVE = @kiadas_eve";
                        command.Parameters.Add("cim", OracleDbType.Varchar2).Value = film.Cim;
                        command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = film.Kiadas_eve;
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            termekek = ReadTermekFromReader(reader);
                            if (termekek.Count == 1)
                            {
                                command.CommandText = "INSERT INTO FILM (TERMEK_ID, RENDEZO) VALUES (@id, @rendezo)";
                                command.Parameters.Add("id", OracleDbType.Int32).Value = termekek[0].ID;
                                command.Parameters.Add("rendezo", OracleDbType.Int32).Value = film.Rendezo;
                                rvSucc = command.ExecuteNonQuery() == 1;
                            }
                        }
                    }
                }
            }
            return rvSucc;
        }

        public bool ujTermek(Zene zene)
        {
            bool rvSucc = false;
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                {
                    command.CommandText = "INSERT INTO TERMEK (CIM, KIADAS_EVE, AR) VALUES (@cim, @kiadas_eve, @ar)";
                    command.Parameters.Add("cim", OracleDbType.Varchar2).Value = zene.Cim;
                    command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = zene.Kiadas_eve;
                    command.Parameters.Add("ar", OracleDbType.Int32).Value = zene.Ar;
                    if (command.ExecuteNonQuery() == 1)
                    {
                        command.CommandText = "SELECT ID FROM TERMEK WHERE CIM = @cim AND KIADAS_EVE = @kiadas_eve";
                        command.Parameters.Add("cim", OracleDbType.Varchar2).Value = zene.Cim;
                        command.Parameters.Add("kiadas_eve", OracleDbType.Int32).Value = zene.Kiadas_eve;
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            termekek = ReadTermekFromReader(reader);
                            if (termekek.Count == 1)
                            {
                                command.CommandText = "INSERT INTO FILM (TERMEK_ID, EGYUTTES_NEVE) VALUES (@id, @egyuttes)";
                                command.Parameters.Add("id", OracleDbType.Int32).Value = termekek[0].ID;
                                command.Parameters.Add("rendezo", OracleDbType.Int32).Value = zene.Egyuttes;
                                rvSucc = command.ExecuteNonQuery() == 1;
                            }
                        }
                    }
                }
            }
            return rvSucc;
        }

        private List<Termek> ReadTermekFromReader (OracleDataReader reader)
        {
            List<Termek> termekek = new List<Termek>();
            while(reader.Read())
            {
                Termek termek = new Termek()
                {
                    ID = reader.GetInt32(reader.GetOrdinal("ID")),
                    Cim = reader.GetString(reader.GetOrdinal("CIM")),
                    Kiadas_eve = reader.GetInt32(reader.GetOrdinal("KIADAS_EVE"))
                };
                termekek.Add(termek);
            }
            return termekek;
        }

        private List<int> ReadIdsFromReader (OracleDataReader reader)
        {
            List<int> ids = new List<int>();
            
            while(reader.Read())
            {
                int i = 0;
                i = reader.GetInt32(reader.GetOrdinal("ID"));
                ids.Add(i);
            }
            return ids;
        }

        private List<Konyv_szerzo> ReadSzerzoFromReader (OracleDataReader reader)
        {
            List<Konyv_szerzo> szerzok = new List<Konyv_szerzo>();

            while(reader.Read())
            {
                Konyv_szerzo szerzo = new Konyv_szerzo()
                {
                    ID = reader.GetInt32(reader.GetOrdinal("ID")),
                    Szerzo = reader.GetString(reader.GetOrdinal("SZERZO"))
                };
                szerzok.Add(szerzo);
            }
            return szerzok;
        }

        private List<Ebook_szerzo> ReadEbookSzerzoFromReader(OracleDataReader reader)
        {
            List<Ebook_szerzo> szerzok = new List<Ebook_szerzo>();

            while (reader.Read())
            {
                Ebook_szerzo szerzo = new Ebook_szerzo()
                {
                    ID = reader.GetInt32(reader.GetOrdinal("ID")),
                    Szerzo = reader.GetString(reader.GetOrdinal("SZERZO"))
                };
                szerzok.Add(szerzo);
            }
            return szerzok;
        }

        public IEnumerable<Konyv> konyvLista()
        {
            List<Konyv_szerzo> szerzok = new List<Konyv_szerzo>();
            List<Konyv> konyvek = new List<Konyv>();
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                //Kiválasztjuk a termékeket, amiknek van külső kulcsa a könyv táblában
                command.CommandText = "SELECT * FROM TERMEK WHERE ID = KONYV.TERMEK_ID";
                using (OracleDataReader termekReader = command.ExecuteReader())
                {
                    termekek = ReadTermekFromReader(termekReader);
                }
                
                //Ha találtunk terméket, megkeressük a szerzőket
                if(termekek.Count > 0)
                {
                        //Kiválasztjuk a szerzőket a táblájukból, aminek van külső kulcsa a könyv táblára
                        command.CommandText = "SELECT * FROM KONYV_SZERZO WHERE KONYV_TERMEK_ID = KONYV.TERMEK_ID";
                        
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            szerzok = ReadSzerzoFromReader(reader);
                        }
                    if(szerzok.Count > 0)
                    {
                        for (int i = 0; i < termekek.Count; i++)
                        {
                            for (int j = 0; j < szerzok.Count; j++)
                            {
                                if (termekek[i].ID == szerzok[j].ID)
                                {
                                    konyvek.Add(new Konyv(termekek[i])
                                    {
                                        Szerzo = szerzok[j].Szerzo
                                    });
                                }
                            }       
                        }
                    }
                }
            }
            return konyvek;
        }

        public IEnumerable<E_book> ebookLista()
        {
            List<Ebook_szerzo> szerzok = new List<Ebook_szerzo>();
            List<E_book> ebookok = new List<E_book>();
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                //Kiválasztjuk a termékeket, amiknek van külső kulcsa a könyv táblában
                command.CommandText = "SELECT * FROM TERMEK WHERE ID = E_BOOK.TERMEK_ID";
                using (OracleDataReader termekReader = command.ExecuteReader())
                {
                    termekek = ReadTermekFromReader(termekReader);
                }

                //Ha találtunk terméket, megkeressük a szerzőket
                if (termekek.Count > 0)
                {
                    //Kiválasztjuk a szerzőket a táblájukból, aminek van külső kulcsa a könyv táblára
                    command.CommandText = "SELECT * FROM E_BOOK_SZERZO WHERE E_BOOK_TERMEK_ID = E_BOOK.TERMEK_ID";

                    using (OracleDataReader reader = command.ExecuteReader())
                    {
                        szerzok = ReadEbookSzerzoFromReader(reader);
                    }
                    if (szerzok.Count > 0)
                    {
                        for (int i = 0; i < termekek.Count; i++)
                        {
                            for (int j = 0; j < szerzok.Count; j++)
                            {
                                if (termekek[i].ID == szerzok[j].ID)
                                {
                                    ebookok.Add(new E_book(termekek[i])
                                    {
                                        Szerzo = szerzok[j].Szerzo
                                    });
                                }
                            }
                        }
                    }
                }
            }
            return ebookok;
        }

        public IEnumerable<Film> filmLista()
        {
            List<Rendezo> rendezok = new List<Rendezo>();
            List<Film> filmek = new List<Film>();
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                //Kiválasztjuk a termékeket, amiknek van külső kulcsa a könyv táblában
                command.CommandText = "SELECT * FROM TERMEK WHERE ID = FILM.TERMEK_ID";
                using (OracleDataReader termekReader = command.ExecuteReader())
                {
                    termekek = ReadTermekFromReader(termekReader);
                }

                //Ha találtunk terméket, megkeressük a szerzőket
                if (termekek.Count > 0)
                {
                    //Kiválasztjuk a szerzőket a táblájukból, aminek van külső kulcsa a könyv táblára
                    command.CommandText = "SELECT * FROM FILM WHERE TERMEK_ID = TERMEK.ID";

                    using (OracleDataReader reader = command.ExecuteReader())
                    {
                        while(reader.Read())
                        {
                            Rendezo rendezo = new Rendezo()
                            {
                                ID = reader.GetInt32(reader.GetOrdinal("ID")),
                                RendezoNeve = reader.GetString(reader.GetOrdinal("Rendezo"))
                            };
                            rendezok.Add(rendezo);
                        }
                    }
                    if (rendezok.Count > 0)
                    {
                        for (int i = 0; i < termekek.Count; i++)
                        {
                            for (int j = 0; j < rendezok.Count; j++)
                            {
                                if (termekek[i].ID == rendezok[j].ID)
                                {
                                    filmek.Add(new Film(termekek[i])
                                    {
                                        Rendezo = rendezok[j].RendezoNeve
                                    });
                                }
                            }
                        }

                    }
                }
            }
            return filmek;
        }

        public IEnumerable<Zene> zeneLista()
        {
            List<Egyuttes> egyuttesek = new List<Egyuttes>();
            List<Zene> zenek = new List<Zene>();
            List<Termek> termekek = new List<Termek>();
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using (OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                //Kiválasztjuk a termékeket, amiknek van külső kulcsa a könyv táblában
                command.CommandText = "SELECT * FROM TERMEK WHERE ID = ZENE.TERMEK_ID";
                using (OracleDataReader termekReader = command.ExecuteReader())
                {
                    termekek = ReadTermekFromReader(termekReader);
                }

                //Ha találtunk terméket, megkeressük a szerzőket
                if (termekek.Count > 0)
                {
                    //Kiválasztjuk a szerzőket a táblájukból, aminek van külső kulcsa a könyv táblára
                    command.CommandText = "SELECT * FROM ZENE WHERE TERMEK_ID = TERMEK.ID";

                    using (OracleDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Egyuttes egyuttes = new Egyuttes()
                            {
                                ID = reader.GetInt32(reader.GetOrdinal("ID")),
                                EgyuttesNeve = reader.GetString(reader.GetOrdinal("EGYUTTES_NEVE"))
                            };
                            egyuttesek.Add(egyuttes);
                        }
                    }
                    if (egyuttesek.Count > 0)
                    {
                        for (int i = 0; i < termekek.Count; i++)
                        {
                            for (int j = 0; j < egyuttesek.Count; j++)
                            {
                                if (termekek[i].ID == egyuttesek[j].ID)
                                {
                                    zenek.Add(new Zene(termekek[i])
                                    {
                                        Egyuttes = egyuttesek[j].EgyuttesNeve
                                    });
                                }
                            }
                        }

                    }
                }
            }
            return zenek;
        }
        #endregion

        //Egy stringet ad vissza, ha admin volt a felhasználó akkor ADMIN-t, egyébként SIKERTELEN vagy SIKERES
        public string login(string username, string pswd)
        {
            string result = "SIKERTELEN";
            using (OracleConnection conn = new OracleConnection(s_connectionString))
            using(OracleCommand command = conn.CreateCommand())
            {
                conn.Open();
                command.CommandText = "SELECT NEV, TIPUS, JELSZO FROM FELHASZNALO WHERE NEV = @nev AND JELSZO = @jelszo";
                command.Parameters.Add("nev", OracleDbType.Varchar2).Value = username;
                command.Parameters.Add("jelszo", OracleDbType.Varchar2).Value = pswd;
                using(OracleDataReader reader = command.ExecuteReader())
                {
                    string nev = "", tipus = "", jelszo = "";
                    while(reader.Read())
                    {
                        nev = reader.GetString(reader.GetOrdinal("NEV"));
                        tipus = reader.GetString(reader.GetOrdinal("TIPUS"));
                        jelszo = reader.GetString(reader.GetOrdinal("JELSZO"));
                    }
                    if(nev == username && jelszo == pswd)
                    {
                        result = "SIKERES";
                        if (tipus == "ADMIN")
                        {
                            result = "ADMIN";
                        }
                    }
                }
            }
            return result;
        }
    }
}
