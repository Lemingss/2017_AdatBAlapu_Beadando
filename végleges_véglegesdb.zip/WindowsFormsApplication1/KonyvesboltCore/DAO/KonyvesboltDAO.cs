﻿using KonyvesboltGUI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.DAO
{
    public interface KonyvesboltDAO
    {
        //bool ujTermek(Termek termek)
        bool ujTermek(Konyv konyv);
        bool ujTermek(E_book ebook);
        bool ujTermek(Film film);
        bool ujTermek(Zene zene);
        IEnumerable<Konyv> konyvLista();
        IEnumerable<E_book> ebookLista();
        IEnumerable<Film> filmLista();
        IEnumerable<Zene> zeneLista();
        string login(string username, string pswd); 

    }
}
