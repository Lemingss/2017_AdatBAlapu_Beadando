﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using KonyvesboltGUI.Controller;
using KonyvesboltGUI.View.Dialogs;

namespace KonyvesboltGUI.View
{
    public partial class KonyvesboltGui : Form
    {
        private KonyvesboltController m_controller;

        public string loginResult
            { get; set; }
        public KonyvesboltController Controller
        {
            get { return m_controller; }
            set { m_controller = value; }
        }
        public KonyvesboltGui()
        {
            InitializeComponent();
        }

        #region segédfüggvények
        public static void ShowMessage(String title, String message)
        {
            MessageBox.Show(
                message,
                title,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
        #endregion

        private void bejelentkezésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using(BejelentkezesDialog dialog = new BejelentkezesDialog(this))
            {
                dialog.ShowDialog();
            }
            if(loginResult == "ADMIN")
            {
                adminToolStripMenuItem.Visible = true;
            }
        }

        private void regisztrációToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using(RegisztracioDialog dialog = new RegisztracioDialog(this))
            {
                dialog.ShowDialog();
            }
        }

        private void felhasználóTörléseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using(AdminDialogTorol dialog = new AdminDialogTorol(this))
            {
                dialog.ShowDialog();
            }
        }
    }
}
