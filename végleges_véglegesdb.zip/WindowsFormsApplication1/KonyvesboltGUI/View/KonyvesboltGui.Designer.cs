﻿namespace KonyvesboltGUI.View
{
    partial class KonyvesboltGui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fájlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bejelentkezésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regisztrációToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.felhasználóTörléseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.újTermékToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.újKönyvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.újEbookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zeneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fájlToolStripMenuItem,
            this.adminToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fájlToolStripMenuItem
            // 
            this.fájlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bejelentkezésToolStripMenuItem,
            this.regisztrációToolStripMenuItem});
            this.fájlToolStripMenuItem.Name = "fájlToolStripMenuItem";
            this.fájlToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fájlToolStripMenuItem.Text = "Fájl";
            // 
            // bejelentkezésToolStripMenuItem
            // 
            this.bejelentkezésToolStripMenuItem.Name = "bejelentkezésToolStripMenuItem";
            this.bejelentkezésToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.bejelentkezésToolStripMenuItem.Text = "Bejelentkezés";
            this.bejelentkezésToolStripMenuItem.Click += new System.EventHandler(this.bejelentkezésToolStripMenuItem_Click);
            // 
            // regisztrációToolStripMenuItem
            // 
            this.regisztrációToolStripMenuItem.Name = "regisztrációToolStripMenuItem";
            this.regisztrációToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.regisztrációToolStripMenuItem.Text = "Regisztráció";
            this.regisztrációToolStripMenuItem.Click += new System.EventHandler(this.regisztrációToolStripMenuItem_Click);
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.felhasználóTörléseToolStripMenuItem,
            this.újTermékToolStripMenuItem});
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.adminToolStripMenuItem.Text = "Admin";
            this.adminToolStripMenuItem.Visible = false;
            // 
            // felhasználóTörléseToolStripMenuItem
            // 
            this.felhasználóTörléseToolStripMenuItem.Name = "felhasználóTörléseToolStripMenuItem";
            this.felhasználóTörléseToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.felhasználóTörléseToolStripMenuItem.Text = "Felhasználó törlése";
            this.felhasználóTörléseToolStripMenuItem.Click += new System.EventHandler(this.felhasználóTörléseToolStripMenuItem_Click);
            // 
            // újTermékToolStripMenuItem
            // 
            this.újTermékToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.újKönyvToolStripMenuItem,
            this.újEbookToolStripMenuItem,
            this.filmToolStripMenuItem,
            this.zeneToolStripMenuItem});
            this.újTermékToolStripMenuItem.Name = "újTermékToolStripMenuItem";
            this.újTermékToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.újTermékToolStripMenuItem.Text = "Új termék";
            // 
            // újKönyvToolStripMenuItem
            // 
            this.újKönyvToolStripMenuItem.Name = "újKönyvToolStripMenuItem";
            this.újKönyvToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.újKönyvToolStripMenuItem.Text = "Könyv";
            // 
            // újEbookToolStripMenuItem
            // 
            this.újEbookToolStripMenuItem.Name = "újEbookToolStripMenuItem";
            this.újEbookToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.újEbookToolStripMenuItem.Text = "Ebook";
            // 
            // filmToolStripMenuItem
            // 
            this.filmToolStripMenuItem.Name = "filmToolStripMenuItem";
            this.filmToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.filmToolStripMenuItem.Text = "Film";
            // 
            // zeneToolStripMenuItem
            // 
            this.zeneToolStripMenuItem.Name = "zeneToolStripMenuItem";
            this.zeneToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.zeneToolStripMenuItem.Text = "Zene";
            // 
            // KonyvesboltGui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "KonyvesboltGui";
            this.Text = "KonyvesboltGui";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fájlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bejelentkezésToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regisztrációToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem felhasználóTörléseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem újTermékToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem újKönyvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem újEbookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zeneToolStripMenuItem;
    }
}