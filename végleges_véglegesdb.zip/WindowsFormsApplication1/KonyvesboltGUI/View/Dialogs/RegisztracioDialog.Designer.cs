﻿namespace KonyvesboltGUI.View.Dialogs
{
    partial class RegisztracioDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.nevTextBox = new System.Windows.Forms.TextBox();
            this.jelszoTextBox = new System.Windows.Forms.TextBox();
            this.irszamNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.hazszamNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.varosTextBox = new System.Windows.Forms.TextBox();
            this.utcaTextBox = new System.Windows.Forms.TextBox();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.irszamNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hazszamNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Felhasználó adatok";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(296, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lakcím adatok";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Felhasználónév:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Jelszó:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(229, 215);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Utca";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(229, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Házszám:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(229, 179);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Város";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(229, 103);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Irányítószám:";
            // 
            // nevTextBox
            // 
            this.nevTextBox.Location = new System.Drawing.Point(102, 100);
            this.nevTextBox.Name = "nevTextBox";
            this.nevTextBox.Size = new System.Drawing.Size(111, 20);
            this.nevTextBox.TabIndex = 11;
            // 
            // jelszoTextBox
            // 
            this.jelszoTextBox.Location = new System.Drawing.Point(102, 141);
            this.jelszoTextBox.Name = "jelszoTextBox";
            this.jelszoTextBox.Size = new System.Drawing.Size(111, 20);
            this.jelszoTextBox.TabIndex = 12;
            // 
            // irszamNumericUpDown
            // 
            this.irszamNumericUpDown.Location = new System.Drawing.Point(305, 103);
            this.irszamNumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.irszamNumericUpDown.Name = "irszamNumericUpDown";
            this.irszamNumericUpDown.Size = new System.Drawing.Size(90, 20);
            this.irszamNumericUpDown.TabIndex = 13;
            this.irszamNumericUpDown.Value = new decimal(new int[] {
            6666,
            0,
            0,
            0});
            // 
            // hazszamNumericUpDown
            // 
            this.hazszamNumericUpDown.Location = new System.Drawing.Point(305, 142);
            this.hazszamNumericUpDown.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.hazszamNumericUpDown.Name = "hazszamNumericUpDown";
            this.hazszamNumericUpDown.Size = new System.Drawing.Size(90, 20);
            this.hazszamNumericUpDown.TabIndex = 14;
            this.hazszamNumericUpDown.Value = new decimal(new int[] {
            66,
            0,
            0,
            0});
            // 
            // varosTextBox
            // 
            this.varosTextBox.Location = new System.Drawing.Point(305, 179);
            this.varosTextBox.Name = "varosTextBox";
            this.varosTextBox.Size = new System.Drawing.Size(90, 20);
            this.varosTextBox.TabIndex = 15;
            // 
            // utcaTextBox
            // 
            this.utcaTextBox.Location = new System.Drawing.Point(305, 215);
            this.utcaTextBox.Name = "utcaTextBox";
            this.utcaTextBox.Size = new System.Drawing.Size(90, 20);
            this.utcaTextBox.TabIndex = 16;
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(15, 211);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 17;
            this.okButton.Text = "&OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(122, 211);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 18;
            this.cancelButton.Text = "&Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // RegisztracioDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 279);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.utcaTextBox);
            this.Controls.Add(this.varosTextBox);
            this.Controls.Add(this.hazszamNumericUpDown);
            this.Controls.Add(this.irszamNumericUpDown);
            this.Controls.Add(this.jelszoTextBox);
            this.Controls.Add(this.nevTextBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "RegisztracioDialog";
            this.Text = "Regisztracio";
            ((System.ComponentModel.ISupportInitialize)(this.irszamNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hazszamNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox nevTextBox;
        private System.Windows.Forms.TextBox jelszoTextBox;
        private System.Windows.Forms.NumericUpDown irszamNumericUpDown;
        private System.Windows.Forms.NumericUpDown hazszamNumericUpDown;
        private System.Windows.Forms.TextBox varosTextBox;
        private System.Windows.Forms.TextBox utcaTextBox;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
    }
}