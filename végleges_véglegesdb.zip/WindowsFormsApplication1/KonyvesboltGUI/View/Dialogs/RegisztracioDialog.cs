﻿using KonyvesboltGUI.Model;
using KonyvesboltGUI.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KonyvesboltGUI.View.Dialogs
{
    public partial class RegisztracioDialog : Form
    {
        private KonyvesboltGui gui;
        public RegisztracioDialog(KonyvesboltGui gui)
        {
            InitializeComponent();

            this.gui = gui;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nevTextBox.Text) || string.IsNullOrEmpty(jelszoTextBox.Text) || string.IsNullOrEmpty(utcaTextBox.Text) || string.IsNullOrEmpty(varosTextBox.Text))
            {
                KonyvesboltGui.ShowMessage(StringConstants.ERROR_TITLE, StringConstants.RegisztracioDialog_MISSING_TEXT);
                return;
            }
            else
            {
                Lakcim lakcim = new Lakcim()
                {
                    Irszam = (int)irszamNumericUpDown.Value,
                    Hazszam = (int)hazszamNumericUpDown.Value,
                    Varos = varosTextBox.Text,
                    Utca = utcaTextBox.Text
                };
                //gui.Controller.UjLakcim(lakcim);
                Felhasznalo felhasznalo = new Felhasznalo()
                {
                    Nev = nevTextBox.Text,
                    Jelszo = jelszoTextBox.Text  
                };

                if(!gui.Controller.register(felhasznalo, lakcim))
                {
                    KonyvesboltGui.ShowMessage(StringConstants.ERROR_TITLE, StringConstants.RegisztracioDialog_ALREADY_REGISTERED);
                }
            } 
        }
    }
}
