﻿using KonyvesboltGUI.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KonyvesboltGUI.View.Dialogs
{
    public partial class AdminDialogTorol : Form
    {
        private KonyvesboltGui gui;
        public AdminDialogTorol(KonyvesboltGui gui)
        {
            InitializeComponent();
            this.gui = gui;

            felhasznaloComboBox.DataSource = gui.Controller.felhasznaloLista();
            felhasznaloComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            felhasznaloComboBox.SelectedIndex = 0;
            
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if(gui.Controller.felhasznaloTorol((string)felhasznaloComboBox.SelectedItem))
            {
                KonyvesboltGui.ShowMessage("Törlés", "Felhasználó törölve!");
            }else
            {
                KonyvesboltGui.ShowMessage(StringConstants.ERROR_TITLE, "Valami hiba történt a törlés során trollolo!");
            }
        }
    }
}
