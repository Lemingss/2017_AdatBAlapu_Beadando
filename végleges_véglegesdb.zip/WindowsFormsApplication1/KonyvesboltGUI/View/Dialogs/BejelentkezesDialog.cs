﻿using KonyvesboltGUI.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KonyvesboltGUI.View.Dialogs
{
    public partial class BejelentkezesDialog : Form
    {

        private KonyvesboltGui gui;
        public BejelentkezesDialog(KonyvesboltGui gui)
        {
            InitializeComponent();

            this.gui = gui;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(usernameTextBox.Text) || string.IsNullOrEmpty(passwordTextBoxs.Text))
            {
                KonyvesboltGui.ShowMessage(StringConstants.ERROR_TITLE, StringConstants.BejelentkezesDialog_MISSING_TEXT);
                return;
            }else
            {
                string loginResult = gui.Controller.login(usernameTextBox.Text, passwordTextBoxs.Text);
                if(loginResult == "SIKERES" || loginResult=="ADMIN")
                {
                    //Kimentjük a login eredményét a guiba egy propertybe, hogy el tudjuk dönteni, hogy milyen guit használjunk(ADMIN/FELHASZNALO)
                    gui.loginResult = loginResult;
                    DialogResult = DialogResult.OK;
                }else
                {
                    KonyvesboltGui.ShowMessage(StringConstants.ERROR_TITLE, StringConstants.BejelentkezesDialog_NOT_REGISTERED);
                    return;
                }
            }
        }
    }
}
