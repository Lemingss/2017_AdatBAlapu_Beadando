﻿using KonyvesboltGUI.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using KonyvesboltGUI.Controller;
using KonyvesboltGUI.View;
using Oracle.ManagedDataAccess.Client;

namespace KonyvesboltGUI
{
    static class Program
    {
        private const string DATABASE_PATH = @"Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=4000)))(CONNECT_DATA=(SID=kabinet)));User Id=h656415;Password=h656415;";
        /*  
   */
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            KonyvesboltDAO dao = new KonyvesboltDAOImpl(DATABASE_PATH);
            KonyvesboltGui gui = new KonyvesboltGui();
            KonyvesboltController controller = new KonyvesboltController();

            gui.Controller = controller;
            controller.Konyvesboltdao = dao;

            Application.Run(gui);
        }
    }
}
