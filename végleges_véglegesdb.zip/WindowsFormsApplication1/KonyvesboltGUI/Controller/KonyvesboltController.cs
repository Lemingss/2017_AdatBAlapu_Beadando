﻿using KonyvesboltGUI.DAO;
using KonyvesboltGUI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.Controller
{
    public class KonyvesboltController
    {
        private KonyvesboltDAO m_dao;

        public KonyvesboltDAO Konyvesboltdao
        {
            get { return m_dao; }
            set { m_dao = value; }
        }

        public bool UjTermek(Konyv konyv)
        {
            return m_dao.ujTermek(konyv);
        }

        public bool UjTermek(E_book ebook)
        {
            return m_dao.ujTermek(ebook);
        }

        public bool UjTermek(Film film)
        {
            return m_dao.ujTermek(film);
        }

        public bool UjTermek(Zene zene)
        {
            return m_dao.ujTermek(zene);
        }

        public IEnumerable<Konyv> konyvLista()
        {
            return m_dao.konyvLista();
        }

        public IEnumerable<E_book> ebookLista()
        {
            return m_dao.ebookLista();
        }

        public IEnumerable<Film> filmLista()
        {
            return m_dao.filmLista();
        }

        public IEnumerable<Zene> zeneLista()
        {
            return m_dao.zeneLista();
        }

        public bool register(Felhasznalo felhasznalo, Lakcim lakcim)
        {
            return m_dao.register(felhasznalo, lakcim);
        }

        public string login(string username, string pswd)
        {
            return m_dao.login(username, pswd);
        }

        public IEnumerable<Felhasznalo> felhasznaloLista()
        {
            return m_dao.felhasznaloLista();
        }

        public bool felhasznaloTorol(string nev)
        {
            return m_dao.felhasznaloTorol(nev);
        }
    }
}
