﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.Model
{
    public class Felhasznalo
    {
        public int ID { get; set; }
        public int Lakcim_ID { get; set; }
        public string Nev { get; set; }
        public string Tipus { get; set; }
        public string Jelszo { get; set; }
        public int Torzsvasarlo { get; set; }
    }
}
