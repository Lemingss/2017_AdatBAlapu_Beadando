﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonyvesboltGUI.Model
{
    public class Lakcim
    {
        public int ID { get; set; }
        public int Irszam { get; set; }
        public int Hazszam { get; set; }
        public string Varos { get; set; }
        public string Utca { get; set; }
    }
}
